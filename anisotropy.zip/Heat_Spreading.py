import math
import numpy as np
import matplotlib.pyplot as plt
from msh2xdmf import import_mesh, msh2xdmf
from dolfin import *
from ufl import Min


# LOAD MESH
mesh, boundaries, subdomains, association_table = import_mesh(prefix='anisotropy', dim=3, subdomains=True)


# FENICS

# Boundary conditions
HTC = 10000. # (W/m2 K)
Tref = 60. # (°C)
qc = 100. * 1e4 # (W/m2)

# Define subdomain markers
markers = MeshFunction('size_t', mesh, 3, mesh.domains())
print("association_table = ", association_table)


# Define thermal conductivity
class Thermal_Conductivity(UserExpression):
    
    # Returns error : ufl.log.UFLException: Can only integrate scalar expressions. The integrand is a tensor expression with value shape (3, 3) and free indices with labels ().
    #def value_shape(self):
    #    return (3,3)
    
    def __init__(self, markers, **kwargs):
        super().__init__(**kwargs) # This part is new!
        self.markers = markers
    
    def eval_cell(self, values, x, cell):
        if self.markers[cell.index] == association_table['base']:
            #values[0] = 100. # isotropic --> works
            values = as_tensor([[100., 0, 0],[0, 100., 0],[0, 0, 100.]])
        else:
            #values[0] = 10. # isotropic --> works
            values = as_tensor([[100., 0, 0],[0, 100., 0],[0, 0, 100.]])
            
k = Thermal_Conductivity(subdomains, degree=1)

# Build function space
V = FunctionSpace(mesh, 'CG', 1)
T = TrialFunction(V)
s = TestFunction(V)
n = FacetNormal(mesh)
ds_bc = ds(subdomain_data=boundaries)

bcs = []

# DEFINE VARIATIONAL FORM
F = (
    - k*inner(grad(T), grad(s))*dx
    - HTC*(T - Tref)*s*ds_bc(association_table["htc"])
    + qc*s*ds_bc(association_table["top1"])
    )

a, L = lhs(F), rhs(F)

# Create VTK files for visualization output
vtkfile_T = File('Temperature.pvd')

T = Function(V, name='Temperature')
#solve(a == L, T, bcs)
solve(a == L, T, bcs, solver_parameters={'linear_solver':'mumps'})

# Save solution to file (VTK)
vtkfile_T << T

# Isotropic max temperature = 310 --> OK
# Anisotropic max temperature = 12000 --> not OK
